﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ClassLibrary1.password;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1.password.Tests
{
    [TestClass()]
    public class passwordcheckerTests
    {
        [TestMethod()]
        public void Check_8Symbols_ReturnsTrue()
        {
            //Arange.
            string password = "ASqw12$$";
            bool expected = true;
            //Act.
            bool actual = passwordchecker.ValidatePassword(password);
        

            //Assert.
            Assert.AreEqual(expected , actual);
        }
    



   
        [TestMethod()]
        public void Check_4Symbols_ReturnsFalse()
        {
            //Arange.

            string password = "Aq1$";
            

            //Act.
            bool actual = passwordchecker.ValidatePassword(password);


            //Assert.
            Assert.IsFalse(actual);
        }

        [TestMethod()]
        public void Check_30Symbols_ReturnsFalse()
        {
            //Arange.
            string password = "ASDqwe123$ASDqwe123$ASDqwe123$";
            bool expected = false;
            //Act.
            bool actual = passwordchecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordWithDigits_ReturnsTrue()
        {
            //Arange.
            string password = "ASDqwe1$";
            bool expected = true;
            //Act.
            bool actual = passwordchecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        public void Check_PasswordWithoutDigits_ReturnsFalse()
        {
            //Arange.
            string password = "ASDqweASD$";
            bool expected = false;
            //Act.
            bool actual = passwordchecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_PasswordWithSpecSymbolsDigits_ReturnsTrue()
        {
            //Arange.
            string password = "Aqwe123$";
            bool expected = true;
            //Act.
            bool actual = passwordchecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_PasswordWithSpecSymbolsDigits_ReturnsFalse()
        {
            //Arange.
            string password = "ASDqwe123";
            bool expected = false;
            //Act.
            bool actual = passwordchecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_PasswordWithCapsSymbolsDigits_ReturnsTrue()
        {
            //Arange.
            string password = "Aqwe123$";
            bool expected = true;
            //Act.
            bool actual = passwordchecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_PasswordWithoutCapsSymbolsDigits_ReturnsFalse()
        {
            //Arange.
            string password = "asdqwe123$";
            bool expected = false;
            //Act.
            bool actual = passwordchecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_PasswordWithLowerSymbolsDigits_ReturnsTrue()
        {
            //Arange.
            string password = "ASDq123$";
            bool expected = true;
            //Act.
            bool actual = passwordchecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }
        [TestMethod()]
        public void Check_PasswordWithoutLowerSymbolsDigits_ReturnsFalse()
        {
            //Arange.
            string password = "ASDQWE123$";
            bool expected = false;
            //Act.
            bool actual = passwordchecker.ValidatePassword(password);


            //Assert.
            Assert.AreEqual(expected, actual);
        }
    }


}